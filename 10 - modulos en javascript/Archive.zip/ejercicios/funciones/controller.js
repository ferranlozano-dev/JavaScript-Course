//Modulo --> parte de código que se puede reutilizar más tarde
//Hay que añadir el export par poder usar las funciones desde cualquier parte

export function suma(a, b){
    return a + b
}

export function multiplica(a, b){
    return a * b
}
