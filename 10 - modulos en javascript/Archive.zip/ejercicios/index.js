//Primero hay que meternos en la carpeta correspondiente y hacer en la terminal
//un mpm init -y

import { suma, multiplica} from './funciones/controller.js'

const ejercicioSuma = suma(4, 4)
console.log(ejercicioSuma)

const ejercicioMultiplica = multiplica(2, 2)
console.log(ejercicioMultiplica)