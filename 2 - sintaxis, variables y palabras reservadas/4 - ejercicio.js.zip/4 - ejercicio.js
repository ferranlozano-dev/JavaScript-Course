let nombre = "Ferran";
let edad = 23;
let pregunta = true;
const fecha = new Date('17 de junio de 1999')
const libro = {
    titulo: "La Sombra del Viento",
    autor: "Carlos Ruiz Zafón",
    fecha_libro: new Date('2001')
}
